$(document).ready(function(){
    let turno = 0;
    $("img").click(function(){
        var idDeImagen = $(this).attr('id');
               
        switch (turno) {
            case 0:
                $(`#${idDeImagen}`).attr("src","./imagenes/O.png");
                turno=1;
                break;
            case 1:
                $(`#${idDeImagen}`).attr("src","./imagenes/X.png");
                turno=0;
                break;
            default:
                break;
        }
    })

    if ($("#img_1").attr("src") == "./imagenes/O.png" && $("#img_2").attr("src") == "./imagenes/O.png" && $("#img_3").attr("src") == "./imagenes/O.png") {
        alert("gano O")        
    }













 });